import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Package, Truck, Home, CheckCircle } from 'lucide-react';

function TrackOrder() {
  const { orderId } = useParams();
  const [orderStatus, setOrderStatus] = useState(null);
  const { t } = useTranslation();

  useEffect(() => {
    const fetchOrderStatus = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/orders/${orderId}/track`, {
          credentials: 'include'
        });
        const data = await response.json();
        setOrderStatus(data);
      } catch (error) {
        console.error('Error fetching order status:', error);
      }
    };

    if (orderId) {
      fetchOrderStatus();
    }
  }, [orderId]);

  const steps = [
    { id: 'processing', icon: Package, label: t('tracking.status.processing') },
    { id: 'shipped', icon: Truck, label: t('tracking.status.shipped') },
    { id: 'outForDelivery', icon: Home, label: t('tracking.status.outForDelivery') },
    { id: 'delivered', icon: CheckCircle, label: t('tracking.status.delivered') }
  ];

  const currentStep = orderStatus?.status || 'processing';
  const currentStepIndex = steps.findIndex(step => step.id === currentStep);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">{t('tracking.title')}</h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="mb-8">
          <p className="text-gray-600 dark:text-gray-400">
            {t('tracking.orderId')}: {orderId}
          </p>
        </div>

        <div className="relative">
          <div className="absolute left-0 top-1/2 w-full h-1 bg-gray-200 dark:bg-gray-700 transform -translate-y-1/2" />
          
          <div className="relative flex justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isCompleted = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;

              return (
                <div key={step.id} className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center relative bg-white dark:bg-gray-800 border-2 ${
                      isCompleted
                        ? 'border-primary-600 text-primary-600'
                        : 'border-gray-300 dark:border-gray-600 text-gray-400 dark:text-gray-500'
                    } ${isCurrent ? 'ring-4 ring-primary-100 dark:ring-primary-900' : ''}`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <p className={`mt-2 text-sm ${
                    isCompleted ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'
                  }`}>
                    {step.label}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {orderStatus?.estimatedDelivery && (
          <div className="mt-8 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-gray-600 dark:text-gray-300">
              Estimated Delivery: {new Date(orderStatus.estimatedDelivery).toLocaleDateString()}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default TrackOrder;