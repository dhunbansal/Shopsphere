import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  products: [{
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true
    },
    name: String,
    price: Number,
    quantity: Number
  }],
  total: Number,
  status: {
    type: String,
    enum: ['processing', 'shipped', 'outForDelivery', 'delivered'],
    default: 'processing'
  },
  customerName: String,
  email: String,
  address: String,
  estimatedDelivery: Date,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Order', orderSchema);